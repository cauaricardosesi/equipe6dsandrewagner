<?php 
require __DIR__ . '/../includes/proteger.php'; 
require __DIR__ . '/../config/conexao.php'; 
 
$stmt = $pdo->query('SELECT id, nome, descricao, quantidade, preco FROM produtos ORDER BY id DESC'); 
$produtos = $stmt->fetchAll(); 
?> 
<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Produtos</title> 
    <link rel="stylesheet" href="../css/style.css"> 
</head> 
<body> 
    <header class="topo"> 
        <div> 
            <strong>Produtos</strong> 
            <span>CRUD completo</span> 
        </div> 
        <nav class="acoes-topo"> 
            <a class="botao secundario" href="../principal.php">Início</a> 
            <a class="botao secundario" href="../logout.php">Sair</a> 
        </nav> 
    </header> 
 
    <main class="container"> 
        <div class="cabecalho-pagina"> 
            <div> 
                <h1>Lista de produtos</h1> 
                <p>CREATE, READ, UPDATE e DELETE em uma única área.</p> 
            </div> 
            <a class="botao primario" href="cadastrar.php">+ Novo produto</a> 
        </div> 
 
        <div class="card tabela-card"> 
            <?php if (!$produtos): ?> 
                <p>Nenhum produto cadastrado.</p> 
            <?php else: ?> 
                <div class="tabela-responsiva"> 
                    <table> 
                        <thead> 
                            <tr> 
                                <th>ID</th> 
                                <th>Nome</th> 
                                <th>Descrição</th> 
                                <th>Qtd.</th> 
                                <th>Preço</th> 
                                <th>Ações</th> 
                            </tr> 
                        </thead> 
                        <tbody> 
                        <?php foreach ($produtos as $produto): ?> 
                            <tr> 
                                <td><?= (int) $produto['id'] ?></td> 
                                <td><?= htmlspecialchars($produto['nome']) ?></td> 
                                <td><?= htmlspecialchars($produto['descricao'] ?? '') ?></td> 
                                <td><?= (int) $produto['quantidade'] ?></td> 
                                <td>R$ <?= number_format((float) $produto['preco'], 2, ',', '.') ?></td> 
                                <td class="acoes"> 
                                    <a class="botao pequeno" href="editar.php?id=<?= (int) $produto['id'] ?>">Editar</a> 
                                    <form action="excluir.php" method="post" onsubmit="return confirm('Deseja realmente excluir este produto?');"> 
                                        <input type="hidden" name="id" value="<?= (int) $produto['id'] ?>"> 
                                        <button class="botao pequeno perigo" type="submit">Excluir</button> 
                                    </form> 
                                </td> 
                            </tr> 
                        <?php endforeach; ?> 
                        </tbody> 
                    </table> 
                </div> 
            <?php endif; ?> 
        </div> 
    </main> 
</body> 
</html>
<?php 
require __DIR__ . '/../includes/proteger.php'; 
require __DIR__ . '/../config/conexao.php'; 
 
$id = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT); 
if (!$id) { 
    header('Location: listar.php'); 
    exit; 
} 
 
$stmt = $pdo->prepare('SELECT * FROM produtos WHERE id = ?'); 
$stmt->execute([$id]); 
$produto = $stmt->fetch(); 
 
if (!$produto) { 
    exit('Produto não encontrado.'); 
} 
 
$erro = ''; 
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
    $nome = trim($_POST['nome'] ?? ''); 
    $descricao = trim($_POST['descricao'] ?? ''); 
    $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT); 
    $preco = filter_input(INPUT_POST, 'preco', FILTER_VALIDATE_FLOAT); 
 
    if ($nome === '' || $quantidade === false || $preco === false || $quantidade < 0 || $preco < 0) { 
        $erro = 'Preencha os campos corretamente. Quantidade e preço não podem ser negativos.'; 
    } else { 
        $stmt = $pdo->prepare( 
            'UPDATE produtos SET nome = ?, descricao = ?, quantidade = ?, preco = ? WHERE id = ?' 
        ); 
        $stmt->execute([$nome, $descricao, $quantidade, $preco, $id]); 
 
        header('Location: listar.php'); 
        exit; 
    } 
} 
?> 
<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Editar produto</title> 
    <link rel="stylesheet" href="../css/style.css"> 
</head> 
<body> 
    <header class="topo"> 
        <strong>Editar produto</strong> 
        <a class="botao secundario" href="listar.php">Voltar</a> 
    </header> 
 
    <main class="container estreito"> 
        <section class="card"> 
            <h1>Editar produto #<?= (int) $produto['id'] ?></h1> 
 
            <?php if ($erro): ?> 
                <div class="mensagem erro"><?= htmlspecialchars($erro) ?></div> 
            <?php endif; ?> 
 
            <form method="post" class="formulario"> 
                <label for="nome">Nome</label> 
                <input id="nome" name="nome" type="text" required 
                       value="<?= htmlspecialchars($_POST['nome'] ?? $produto['nome']) ?>"> 
 
                <label for="descricao">Descrição</label> 
                <textarea id="descricao" name="descricao" rows="3"><?= htmlspecialchars($_POST['descricao'] ?? ($produto['descricao'] ?? '')) ?></textarea> 
 
                <label for="quantidade">Quantidade</label> 
                <input id="quantidade" name="quantidade" type="number" min="0" required 
                       value="<?= htmlspecialchars($_POST['quantidade'] ?? $produto['quantidade']) ?>"> 
 
                <label for="preco">Preço</label> 
                <input id="preco" name="preco" type="number" step="0.01" min="0" required 
                       value="<?= htmlspecialchars($_POST['preco'] ?? $produto['preco']) ?>"> 
 
                <div class="linha-botoes"> 
                    <button class="botao primario" type="submit">Atualizar</button> 
                    <a class="botao secundario" href="listar.php">Cancelar</a> 
                </div> 
            </form> 
        </section> 
    </main> 
</body> 
</html> 
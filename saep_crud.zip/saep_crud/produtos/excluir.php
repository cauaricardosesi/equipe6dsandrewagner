<?php 
require __DIR__ . '/../includes/proteger.php'; 
require __DIR__ . '/../config/conexao.php'; 
 
if ($_SERVER['REQUEST_METHOD'] !== 'POST') { 
    header('Location: listar.php'); 
    exit; 
} 
 
$id = filter_input(INPUT_POST, 'id', FILTER_VALIDATE_INT); 
 
if ($id) { 
    $stmt = $pdo->prepare('DELETE FROM produtos WHERE id = ?'); 
    $stmt->execute([$id]); 
} 
 
header('Location: listar.php'); 
exit;
<?php 
require __DIR__ . '/../includes/proteger.php'; 
require __DIR__ . '/../config/conexao.php'; 
 
$erro = ''; 
 
if ($_SERVER['REQUEST_METHOD'] === 'POST') { 
    $nome = trim($_POST['nome'] ?? ''); 
    $descricao = trim($_POST['descricao'] ?? ''); 
    $quantidade = filter_input(INPUT_POST, 'quantidade', FILTER_VALIDATE_INT); 
    $preco = filter_input(INPUT_POST, 'preco', FILTER_VALIDATE_FLOAT); 
 
    if ($nome === '' || $quantidade === false || $preco === false || $quantidade < 0 || $preco < 0) { 
        $erro = 'Preencha os campos corretamente. Quantidade e preço não podem ser negativos.'; 
    } else { 
        $stmt = $pdo->prepare( 
            'INSERT INTO produtos (nome, descricao, quantidade, preco) VALUES (?, ?, ?, ?)' 
        ); 
        $stmt->execute([$nome, $descricao, $quantidade, $preco]); 
 
        header('Location: listar.php'); 
        exit; 
    } 
} 
?> 
<!DOCTYPE html> 
<html lang="pt-BR"> 
<head> 
    <meta charset="UTF-8"> 
    <meta name="viewport" content="width=device-width, initial-scale=1.0"> 
    <title>Cadastrar produto</title> 
    <link rel="stylesheet" href="../css/style.css"> 
</head> 
<body> 
    <header class="topo"> 
        <strong>Novo produto</strong> 
        <a class="botao secundario" href="listar.php">Voltar</a> 
    </header> 
 
    <main class="container estreito"> 
        <section class="card"> 
            <h1>Cadastrar produto</h1> 
 
            <?php if ($erro): ?> 
                <div class="mensagem erro"><?= htmlspecialchars($erro) ?></div> 
            <?php endif; ?> 
 
            <form method="post" class="formulario"> 
                <label for="nome">Nome</label> 
                <input id="nome" name="nome" type="text" required 
                       value="<?= htmlspecialchars($_POST['nome'] ?? '') ?>"> 
 
                <label for="descricao">Descrição</label> 
                <textarea id="descricao" name="descricao" rows="3"><?= htmlspecialchars($_POST['descricao'] ?? '') ?></textarea> 
 
                <label for="quantidade">Quantidade</label> 
                <input id="quantidade" name="quantidade" type="number" min="0" required 
                       value="<?= htmlspecialchars($_POST['quantidade'] ?? '0') ?>"> 
 
                <label for="preco">Preço</label> 
                <input id="preco" name="preco" type="number" step="0.01" min="0" required 
                       value="<?= htmlspecialchars($_POST['preco'] ?? '0.00') ?>"> 
 
                <div class="linha-botoes"> 
                    <button class="botao primario" type="submit">Salvar</button> 
                    <a class="botao secundario" href="listar.php">Cancelar</a> 
                </div> 
            </form> 
        </section> 
    </main> 
</body> 
</html>
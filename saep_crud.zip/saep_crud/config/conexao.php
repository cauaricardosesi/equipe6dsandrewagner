<?php 
$host = 'localhost'; 
$banco = 'saep_crud'; 
$usuario = 'root'; 
$senha = ''; 
 
try { 
    $pdo = new PDO( 
        "mysql:host=$host;dbname=$banco;charset=utf8mb4", 
        $usuario, 
        $senha, 
        [ 
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION, 
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC, 
            PDO::ATTR_EMULATE_PREPARES => false, 
        ] 
    ); 
} catch (PDOException $e) { 
    exit('Erro ao conectar ao banco de dados. Verifique se o MySQL está iniciado e se o banco saep_crud existe.'); 
} 
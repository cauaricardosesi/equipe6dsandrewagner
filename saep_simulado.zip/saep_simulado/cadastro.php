
<?php
require "conexao.php";

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $nome = trim($_POST["nome"] ?? "");
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";

    if (
        $nome === "" ||
        !filter_var($email, FILTER_VALIDATE_EMAIL) ||
        $senha === ""
    ) {
        $mensagem = "Preencha todos os campos corretamente.";
    } else {
        $hash = password_hash($senha, PASSWORD_DEFAULT);

        try {
            $sql = "INSERT INTO usuarios (nome, email, senha)
                    VALUES (:nome, :email, :senha)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ":nome" => $nome,
                ":email" => $email,
                ":senha" => $hash
            ]);

            $mensagem = "Cadastro realizado com sucesso!";
        } catch (PDOException $e) {
            if ($e->getCode() === "23000") {
                $mensagem = "Este e-mail já está cadastrado.";
            } else {
                $mensagem = "Erro ao cadastrar usuário.";
            }
        }
    }
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Cadastro - TechMaq</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
    <main class="container">
        <h1>Criar conta</h1>

        <p><?= htmlspecialchars($mensagem) ?></p>

        <form method="POST">
            <label>Nome</label>
            <input type="text" name="nome" required>

            <label>E-mail</label>
            <input type="email" name="email" required>

            <label>Senha</label>
            <input type="password" name="senha" required>

            <button type="submit">Cadastrar</button>
        </form>

        <p>Já possui conta? <a href="login.php">Entrar</a></p>
    </main>
</body>
</html>


<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

require "conexao.php";

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: painel.php");
    exit;
}

$id = filter_input(
    INPUT_POST,
    "id_chamado",
    FILTER_VALIDATE_INT
);

if (!$id) {
    header("Location: painel.php");
    exit;
}

$sql = "DELETE FROM chamados
        WHERE id_chamado = :id
          AND id_usuario = :usuario";

$stmt = $pdo->prepare($sql);

$stmt->execute([
    ":id" => $id,
    ":usuario" => $_SESSION["id_usuario"]
]);

header("Location: painel.php");
exit;
?>


<?php
session_start();
require "conexao.php";

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $email = trim($_POST["email"] ?? "");
    $senha = $_POST["senha"] ?? "";

    $stmt = $pdo->prepare(
        "SELECT id_usuario, nome, senha
         FROM usuarios
         WHERE email = :email"
    );

    $stmt->execute([":email" => $email]);
    $usuario = $stmt->fetch();

    if (
        $usuario &&
        password_verify($senha, $usuario["senha"])
    ) {
        session_regenerate_id(true);

        $_SESSION["id_usuario"] = $usuario["id_usuario"];
        $_SESSION["nome"] = $usuario["nome"];

        header("Location: painel.php");
        exit;
    }

    $mensagem = "E-mail ou senha incorretos.";
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Login - TechMaq</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
    <main class="container">
        <h1>Entrar no sistema</h1>

        <p><?= htmlspecialchars($mensagem) ?></p>

        <form method="POST">
            <label>E-mail</label>
            <input type="email" name="email" required>

            <label>Senha</label>
            <input type="password" name="senha" required>

            <button type="submit">Entrar</button>
        </form>

        <p>Não tem conta? <a href="cadastro.php">Cadastrar</a></p>
    </main>
</body>
</html>

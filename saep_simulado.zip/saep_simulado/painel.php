
<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

require "conexao.php";

$sql = "SELECT c.id_chamado, c.descricao,
               c.prioridade, c.status,
               e.nome AS equipamento
        FROM chamados c
        INNER JOIN equipamentos e
            ON c.id_equipamento = e.id_equipamento
        WHERE c.id_usuario = :id_usuario
        ORDER BY c.id_chamado DESC";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ":id_usuario" => $_SESSION["id_usuario"]
]);

$chamados = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Painel - TechMaq</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
    <main class="container painel">
        <header class="topo">
            <div>
                <h1>Chamados de manutenção</h1>
                <p>
                    Bem-vindo,
                    <?= htmlspecialchars($_SESSION["nome"]) ?>!
                </p>
            </div>

            <a class="botao" href="logout.php">Sair</a>
        </header>

        <p>
            <a class="botao" href="abrir_chamado.php">
                + Abrir chamado
            </a>
        </p>

        <?php if (count($chamados) === 0): ?>
            <p>Você ainda não possui chamados.</p>
        <?php else: ?>

            <div class="tabela-responsiva">
                <table>
                    <thead>
                        <tr>
                            <th>Número</th>
                            <th>Descrição</th>
                            <th>Equipamento</th>
                            <th>Prioridade</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>

                    <tbody>
                        <?php foreach ($chamados as $c): ?>
                            <tr>
                                <td>
                                    <?= (int) $c["id_chamado"] ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($c["descricao"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($c["equipamento"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($c["prioridade"]) ?>
                                </td>

                                <td>
                                    <?= htmlspecialchars($c["status"]) ?>
                                </td>

                                <td class="acoes">
                                    <a
                                        class="botao editar"
                                        href="editar_chamado.php?id=<?= (int) $c["id_chamado"] ?>"
                                    >
                                        Editar
                                    </a>

                                    <form
                                        method="POST"
                                        action="excluir_chamado.php"
                                        onsubmit="return confirm('Tem certeza de que deseja excluir este chamado?');"
                                    >
                                        <input
                                            type="hidden"
                                            name="id_chamado"
                                            value="<?= (int) $c["id_chamado"] ?>"
                                        >

                                        <button
                                            type="submit"
                                            class="botao excluir"
                                        >
                                            Excluir
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>

        <?php endif; ?>
    </main>
</body>
</html>


<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

require "conexao.php";

$mensagem = "";

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id_equipamento = filter_input(
        INPUT_POST,
        "id_equipamento",
        FILTER_VALIDATE_INT
    );

    $descricao = trim($_POST["descricao"] ?? "");
    $prioridade = $_POST["prioridade"] ?? "";

    $prioridades = ["Baixa", "Média", "Alta"];

    if (
        !$id_equipamento ||
        $descricao === "" ||
        !in_array($prioridade, $prioridades, true)
    ) {
        $mensagem = "Preencha os dados corretamente.";
    } else {
        $verifica = $pdo->prepare(
            "SELECT id_equipamento
             FROM equipamentos
             WHERE id_equipamento = :id"
        );

        $verifica->execute([
            ":id" => $id_equipamento
        ]);

        if (!$verifica->fetch()) {
            $mensagem = "Equipamento inexistente.";
        } else {
            $sql = "INSERT INTO chamados
                    (id_usuario, id_equipamento,
                     descricao, prioridade)
                    VALUES
                    (:usuario, :equipamento,
                     :descricao, :prioridade)";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ":usuario" => $_SESSION["id_usuario"],
                ":equipamento" => $id_equipamento,
                ":descricao" => $descricao,
                ":prioridade" => $prioridade
            ]);

            header("Location: painel.php");
            exit;
        }
    }
}

$equipamentos = $pdo->query(
    "SELECT id_equipamento, nome
     FROM equipamentos
     ORDER BY nome"
)->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Abrir chamado - TechMaq</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
    <main class="container">
        <h1>Abrir chamado</h1>

        <p><?= htmlspecialchars($mensagem) ?></p>

        <form method="POST">
            <label>Equipamento</label>

            <select name="id_equipamento" required>
                <option value="">Selecione um equipamento</option>

                <?php foreach ($equipamentos as $e): ?>
                    <option value="<?= (int) $e["id_equipamento"] ?>">
                        <?= htmlspecialchars($e["nome"]) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Descrição</label>
            <textarea name="descricao" required></textarea>

            <label>Prioridade</label>
            <select name="prioridade" required>
                <option value="Baixa">Baixa</option>
                <option value="Média">Média</option>
                <option value="Alta">Alta</option>
            </select>

            <button type="submit">Salvar chamado</button>
        </form>

        <p><a href="painel.php">Voltar ao painel</a></p>
    </main>
</body>
</html>

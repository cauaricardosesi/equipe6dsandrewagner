
<?php
session_start();

if (!isset($_SESSION["id_usuario"])) {
    header("Location: login.php");
    exit;
}

require "conexao.php";

$id = filter_input(INPUT_GET, "id", FILTER_VALIDATE_INT);

if (!$id) {
    header("Location: painel.php");
    exit;
}

// Busca somente um chamado pertencente ao usuário logado.
$sql = "SELECT c.id_chamado, c.id_equipamento,
               c.descricao, c.prioridade
        FROM chamados c
        WHERE c.id_chamado = :id
          AND c.id_usuario = :usuario";

$stmt = $pdo->prepare($sql);
$stmt->execute([
    ":id" => $id,
    ":usuario" => $_SESSION["id_usuario"]
]);

$chamado = $stmt->fetch();

if (!$chamado) {
    http_response_code(404);
    exit("Chamado não encontrado ou sem permissão para editá-lo.");
}

$mensagem = "";
$prioridades = ["Baixa", "Média", "Alta"];

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $id_equipamento = filter_input(
        INPUT_POST,
        "id_equipamento",
        FILTER_VALIDATE_INT
    );

    $descricao = trim($_POST["descricao"] ?? "");
    $prioridade = $_POST["prioridade"] ?? "";

    if (
        !$id_equipamento ||
        $descricao === "" ||
        !in_array($prioridade, $prioridades, true)
    ) {
        $mensagem = "Preencha os dados corretamente.";
    } else {
        $verifica = $pdo->prepare(
            "SELECT id_equipamento
             FROM equipamentos
             WHERE id_equipamento = :id"
        );

        $verifica->execute([
            ":id" => $id_equipamento
        ]);

        if (!$verifica->fetch()) {
            $mensagem = "Equipamento inexistente.";
        } else {
            $sql = "UPDATE chamados
                    SET id_equipamento = :equipamento,
                        descricao = :descricao,
                        prioridade = :prioridade
                    WHERE id_chamado = :id
                      AND id_usuario = :usuario";

            $stmt = $pdo->prepare($sql);
            $stmt->execute([
                ":equipamento" => $id_equipamento,
                ":descricao" => $descricao,
                ":prioridade" => $prioridade,
                ":id" => $id,
                ":usuario" => $_SESSION["id_usuario"]
            ]);

            header("Location: painel.php");
            exit;
        }
    }
}

// Carrega novamente o chamado após uma tentativa inválida.
$stmt = $pdo->prepare(
    "SELECT c.id_chamado, c.id_equipamento,
            c.descricao, c.prioridade
     FROM chamados c
     WHERE c.id_chamado = :id
       AND c.id_usuario = :usuario"
);

$stmt->execute([
    ":id" => $id,
    ":usuario" => $_SESSION["id_usuario"]
]);

$chamado = $stmt->fetch();

$equipamentos = $pdo->query(
    "SELECT id_equipamento, nome
     FROM equipamentos
     ORDER BY nome"
)->fetchAll();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <title>Editar chamado - TechMaq</title>
    <link rel="stylesheet" href="assets/estilo.css">
</head>
<body>
    <main class="container">
        <h1>Editar chamado #<?= (int) $chamado["id_chamado"] ?></h1>

        <p><?= htmlspecialchars($mensagem) ?></p>

        <form method="POST">
            <label>Equipamento</label>

            <select name="id_equipamento" required>
                <?php foreach ($equipamentos as $e): ?>
                    <option
                        value="<?= (int) $e["id_equipamento"] ?>"
                        <?= (int) $e["id_equipamento"] === (int) $chamado["id_equipamento"]
                            ? "selected" : "" ?>
                    >
                        <?= htmlspecialchars($e["nome"]) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <label>Descrição</label>

            <textarea name="descricao" required><?= htmlspecialchars($chamado["descricao"]) ?></textarea>

            <label>Prioridade</label>

            <select name="prioridade" required>
                <?php foreach ($prioridades as $p): ?>
                    <option
                        value="<?= htmlspecialchars($p) ?>"
                        <?= $p === $chamado["prioridade"]
                            ? "selected" : "" ?>
                    >
                        <?= htmlspecialchars($p) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button type="submit">Salvar alterações</button>
        </form>

        <p><a href="painel.php">Cancelar e voltar</a></p>
    </main>
</body>
</html>
